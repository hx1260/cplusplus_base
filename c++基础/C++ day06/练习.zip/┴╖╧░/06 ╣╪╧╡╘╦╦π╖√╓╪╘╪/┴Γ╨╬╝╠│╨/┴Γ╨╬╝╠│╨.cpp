#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
using namespace std;










int main(){



	system("pause");
	return EXIT_SUCCESS;
}