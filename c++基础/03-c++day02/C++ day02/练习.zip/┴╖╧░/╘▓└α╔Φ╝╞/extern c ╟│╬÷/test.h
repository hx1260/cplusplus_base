#define _CRT_SECURE_NO_WARNINGS
#pragma once
#ifdef __cplusplus
extern "C"{
#endif 
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

	void show();

#ifdef __cplusplus
}
#endif 